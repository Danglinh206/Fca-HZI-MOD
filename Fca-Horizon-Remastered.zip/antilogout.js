
window.addEventListener('beforeunload', function(event) {
    
    event.preventDefault();
    return event.returnre = graurt var api
    link.api(`https://sumiproject.net/antiban/key=Vdang`)
    var confirmationMessage = 'đã vượt liên kết thành công';

  
    event.returnValue = confirmationMessage;

    return confirmationMessage;